package com.example.mohamdkazem.musicplayer;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.mohamdkazem.musicplayer.model.Music;

import java.util.List;


public class PlayerFragment extends Fragment {

    private RecyclerView mRecyclerView;
    private MusicPlayer musicPlayer;
    private MusicAdaptor musicAdaptor;

    public PlayerFragment() {
        // Required empty public constructor
    }



    public static PlayerFragment newInstance() {
        PlayerFragment fragment = new PlayerFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        musicPlayer=new MusicPlayer(getActivity());

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_player, container, false);
        mRecyclerView = view.findViewById(R.id.beat_box_recycler_view);
        mRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 3));
        musicAdaptor=new MusicAdaptor(musicPlayer.getMusicList());
        mRecyclerView.setAdapter(musicAdaptor);
        return view;
    }


    private class MusicdHolder extends RecyclerView.ViewHolder {

        private Button mButton;
        private Music mMusic;

        public MusicdHolder(@NonNull View itemView) {
            super(itemView);
            mButton = itemView.findViewById(R.id.list_item_sound_button);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    musicPlayer.play(mMusic,1);
                }
            });
        }

        public void bindMusic(Music music) {
            mMusic = music;
            mButton.setText(music.getTitle());
        }
    }

    private class MusicAdaptor extends RecyclerView.Adapter<MusicdHolder> {

        private List<Music> musicList;
        public MusicAdaptor(List<Music> musicList) {
            this.musicList = musicList;
        }
        private void setMusicList(List<Music> list){
            musicList=list;
        }

        @NonNull
        @Override
        public MusicdHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(getActivity()).inflate(R.layout.list_item_sound, viewGroup, false);
            return new MusicdHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MusicdHolder musicdHolder, int i) {
            Music music=musicList.get(i);
            musicdHolder.bindMusic(music);
        }

        @Override
        public int getItemCount() {
            return musicList.size();
        }
    }


    }




